summary.facROC <-
function(x,...){
   cat("ANOVA-Type Statistic \n")
   print(x$teststatistic)
   cat("\n")
   }
