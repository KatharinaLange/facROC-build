invlogit <-
function(x){exp(x)/(exp(x)+1)}
