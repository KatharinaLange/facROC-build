summary.facROC <-
function(object,...){
   cat("ANOVA-Type Statistic \n")
   print(object$teststatistic)
   cat("\n")
   }
